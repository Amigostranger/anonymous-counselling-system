package com.example.harmony.fragment2;

public class CounsDetails {
    public static String Counsellor_id = "";
    public static String Patient = "No recent messages";
    public static String Name = "";
    public static String getProblem = "-1";
}
